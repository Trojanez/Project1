<?php

class Car extends Vehicle {
	protected $rotateWheelKof = 1;
	protected $changeSpeedKof = 10;
}