<?php

Interface IVehicle {

	public function changePressure($p);
	public function rotateWheel($r);
	public function getSpeed();
	public function getCoordinate();
	public function getDirection();
}