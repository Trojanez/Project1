<?php

Abstract class Vehicle implements IVehicle {
	private $speed = 0;
	private $direction = 0;
	private $coordinate = array('x' => 0, 'y' => 0);
	private $time;
	protected $rotateWheelKof;
	protected $changeSpeedKof;

	public function __construct($sessioKey = null){

		if ($sessionKey) {
			$this->restoreFromSession($sessionKey);
		} else 
		$this->time = time();
	}

	protected function setSpeed($speed) {
		$this->speed = $speed;
	}

	public function getSpeed($speed) {
		return $this->speed;
	}

	public function changePressure($p) {
		$this->recalculateState();
		$this->setSpeed($this->getSpeed() + $p*$this->changeSpeedKof);
	}

	public function rotateWheel($p) {
		$this->recalculateState();
		$this->direction += $p*$this
	}

	private function recalculateState() {
		$this->coordinate = $this->getCoordinate();
		$this->time = time();
	}

	private function _getCoordinate() {
		return $this->coordinate;
	}

	public function getCoordinate() {
		$coordinate = $this->_getCoordinate();
		$coordinate = $coordinate['x'] + (time()) - $this->time * $this->getSpeed();
		// $coordinate = $coordinate['y'] + (time()) - $this->time * $this->getSpeed();
		return $coordinate;
	}
	public function getDirection() {
		return $this->direction;
	}

	public function restoreFromSession($key) {
		if (isset($_SESSION[$key]))
	}



}