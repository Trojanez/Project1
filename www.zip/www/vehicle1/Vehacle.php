<?php

abstract class Vehacle implements IVehacle{
    private $speed = 0;
    private $direction = 0;//degre
    private $coordinate = array('x'=>0, 'y'=>0);
    private $time;
    protected $rotateWheelKof;
    protected $changeSpeedKof;

    public function __construct($Key = false)
    {
        if ($Key) {
            $this->key = $key;
        } 
        $this->restoreData();
        }
    }

    protected function setSpeed($speed){

        $this->speed = $speed;
    }

    public function getSpeed(){

        return $this->speed ;
    }

    public function changePressure($p)
    {
        $this->recalculateState();
        $this->setSpeed($this->getSpeed() + $p*$this->changeSpeedKof());
    }

    public function rotateWheel($p) {
        $this->recalculateState();
        $this->direction += $p*$this->rotateWheelKof();
    }

    private function recalculateState() {
        $this->coordinate = $this->getCoordinate();
        $this->time = time();
    }

    private function _getCoordinate() {
        return $this->coordinate;
    }

    public function getCoordinate() {
        $coordinate = $this->_getCoordinate();
        $coordinate['x'] += (time() - $this->time) * $this->getSpeed();
//      $coordinate['y'] += (time() - $this->time) * $this->getSpeed();
        return $coordinate;
    }

    function getDirection(){
        return $this->direction;
    }


    public function saveToSession($key) {
        $_SESSION[$key]['speed'] = $this->getSpeed();
        $_SESSION[$key]['direction'] = $this->getDirection();
        $_SESSION[$key]['coordinates'] = $this->_getCoordinate();
        $_SESSION[$key]['time'] = $this->time;
    }

    private function restoreFromSession($key) {
        if (isset($_SESSION[$key]['speed'])) {
            $this->setSpeed($_SESSION[$key]['speed']);
        }
        if (isset($_SESSION[$key]['direction'])) {
            $this->direction = $_SESSION[$key]['direction'];
        }
        if (isset($_SESSION[$key]['coordinates'])) {
            $this->coordinate = $_SESSION[$key]['coordinates'];
        }
        if (isset($_SESSION[$key]['time'])) {
            $this->time = $_SESSION[$key]['time'];
        }
    }
}


public function save() {
    $dbLink = Db::getInstance()->getLink();
    mysqli_begin_transaction($dbLink);

    $stmt = mysqli_prepare(
    $dbLink,
        "INSERT INTO vehicle ('key') VALUES (?)"
            );
        if ($stmt) {
            mysqli_stmt_bind_param($stmt, "s", $this->key);
            /* запускаем запрос */
            $success = mysqli_stmt_execute($stmt);
            /* закрываем запрос */
            mysqli_stmt_close($stmt);
    }
    $query = "INSERT INTO speed (v_id, 'value') VALUES (?, ?)";
    $stmt = mysqli_prepare($dbLink, $query);
        if ($stmt) {
            mysqli_stmt_bind_param($stmt, "ii", $insertId, $speed);
            /* запускаем запрос */
            $success = mysqli_stmt_execute($stmt);
            /* закрываем запрос */
            mysqli_stmt_close($stmt);
}

private function restoreData() {
    $dbLink = Db::getInstance()->getLink();
    $query = "select v.id vid, v.key 'key', t.value 'time', 'c'.value_x, 'c'.value_y, d.value direction, s.value speed
    from vehicle
    join 'time' on t.v_id = v.id
    join speed s on s.v_id = v.id
    join coordinate c on c.v_id = v.id
    join direction d on d.v_id = v.id
    where v.key = ?";

        if ($stmt = mysqli_prepare($dbLink, $query)) {
            mysqli_stmt_bind_param($stmt, "s", $this->key);
            mysqli_stmt_execute($stmt);
            $result = mysqli_stmt_get_result($stmt);
            $vehicleData = mysqli_fetch_array($result, MYSQLI_ASSOC);
            if (!$vehicleData) {
                $newData = true;
                $vehicleData = array(
                    'speed' =>0,
                    'direction' => 0,
                    'time' => time(),
                    'c_y' => 0,
                    'c_x' => 0,
                    );
            }
            $this->setSpeed($vehicleData['speed']);
            $this->setDirection($vehicleData['direction']);
            $this->setCoordinate(['x' => $vehicleData['c_x'], 'y' => $vehicleData['c_y']);
            $this->time() = $vehicleData['time'];
            mysqli_stmt_close($stmt);
            if(!empty($newData)) {
                $this->save();
            }
        }
}