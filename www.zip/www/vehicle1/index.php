<?php


spl_autoload_register(function ($fileName) {
    include_once  $fileName . '.php';
});

session_start();
$sessionKey = 'car1';
$car = new Car($sessionKey);

if (isset($_POST['rotate_right'])) {
    $car->rotateWheel($_POST['rotate_amount']);
} elseif (isset($_POST['rotate_left'])) {
    $car->rotateWheel(-$_POST['rotate_amount']);
}
if (isset($_POST['pedal_pressure_up'])) {
    $car->changePressure($_POST['pedal_pressure_amount']);
} elseif (isset($_POST['pedal_pressure_down'])) {
    $car->changePressure(-$_POST['pedal_pressure_amount']);
}

$car->saveToSession($sessionKey);

include 'index.phtml';