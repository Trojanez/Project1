<?php

class Car extends Vehacle{
    protected $rotateWheelKof = 1;
    protected $changeSpeedKof = 2;

}