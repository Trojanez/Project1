<?php
interface IVehacle {
    
    function changePressure($p);
    function rotateWheel($p);
    function getCoordinate();
    function getSpeed();
    function getDirection();
    
    
}


