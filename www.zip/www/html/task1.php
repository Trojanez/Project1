<b>Производим вычисления скорости, времени и расстояния! Enjoy!</b></br></br>
<form>
	Введите скорость:</br>
	<input type="text" name="velocity" placeholder="Скорость"/></br></br>
	Введите расстояние:</br>
	<input type="text" name="distance" placeholder="Расстояние"/></br></br>
	Введите время:</br>
	<input type="text" name="time" placeholder="Время"/></br></br>
	<input type="submit" value="GO!"/>
</form>
