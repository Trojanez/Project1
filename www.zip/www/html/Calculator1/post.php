<?php
	require "Calculator.php";

if(isset($_POST['send'])) {
	$a = $_POST['digit1'];
	$b = $_POST['digit2'];
	$operator = $_POST['operation'];

$calculator = new Calculator; 
	$result = $calculator->calculate($a, $b, $operator);
}

