<?php

Class Delete {

	public function Calculate($a, $b) {
		return $a / $b;
	}
}