<?php

interface OperatorInterface{

  	public function Calculate($a, $b, $operator);
}