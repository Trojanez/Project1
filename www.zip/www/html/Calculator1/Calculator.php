<?php

  require "Sum.php";
  require "Minus.php";
  require "Delete.php";
  require "Multiply.php";
require_once "OperatorInterface.php";

Class Calculator implements OperatorInterface {

  	public function calculate($a, $b, $operator) {
  		switch ($operator) {
  			case "+": $result = new Sum(); $result->Calculate($a, $b); break;
  			case "-": $result = new Minus(); $result->Calculate($a, $b); break;
  			case "*": $result = new Multiply(); $result->Calculate($a, $b); break;
  			case "/": $result = new Delete(); $result->Calculate($a, $b); break;
        	default: die("smth went wrong!");  

  		}
      echo $result -> Calculate($a, $b);
  	}
}