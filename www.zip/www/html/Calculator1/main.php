<?php


	require "post.php";


	require "form.phtml";
