<?php

Class Minus {

	public function Calculate($a, $b) {
		return $a - $b;
	}
}