<?php

require_once "OperatorInterface.php";

Class Sum {

	public function Calculate($a, $b) {
		return $a + $b;
	}
}