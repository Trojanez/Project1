<?php

	$velocity = isset($_GET['velocity']) ? ($_GET['velocity']) : " ";
	$distance = isset($_GET['distance']) ? ($_GET['distance']) : " ";
	$time = isset($_GET['time']) ? ($_GET['time']) : " ";

	if (empty($velocity) and empty($distance) and empty($time)){
		echo "Поля не могут быть пустыми";
	}elseif (!is_numeric($velocity) and !is_numeric($distance) and !is_numeric($time)){
		echo "Вводить можно только цифры.";
	}elseif ($velocity <= 0 && $distance <= 0 && $time <= 0){
		echo "Поля не могут быть 0 или отрицательными.";
	}elseif (!empty($velocity) and !empty($distance) and !empty($time)){
		echo "Все поля не могут быть заполенены.";
	}




?>
