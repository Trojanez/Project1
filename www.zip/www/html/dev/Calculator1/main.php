<?php

	require "Interface.php";
	require "post.php";
	require "Sum.php";
	require "Minus.php";
	require "Delete.php";
	require "Multiply.php";
	require "form.phtml";