<?php

Class Calculator {

	public function Calculate ($operator) {
		switch ($operator) {
			case "+": $operation = new Sum($a, $b); 
			break;
			case "-": $operation = new Minus($a, $b); 
			break;
			case "/": $operation = new Delete($a, $b); 
			break;
			case "*": $operation = new Multiply($a, $b); 
			break;
		}
		print "Ответ: {$operation->Calculate()}\n";
	}
}