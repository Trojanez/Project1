<?php

Class Multiply {
	public $a;
	public $b;

	public function Calculate() {
		return $a * $b;
	}
}