<?php

Class Sum {
	public $a;
	public $b;

	public function Calculate() {
		return $a + $b;
	}
}