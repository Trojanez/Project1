<p><b>Форма регистрации:</b></p></br>

<form action="main.php" method="post">


	<label for="login">Введите логин:</label></br>
	<input type="text" name="login"/></br>
	<label for="email">Введите Ваш электронный адрес:</label></br>
	<input type="email" name="email"/></br>
	<label for="password1">Введите Ваш пароль:</label></br>
	<input type="password" name="password1"/></br>
	<label for="password2">Введите Ваш пароль повторно:</label></br>
        <input type="password" name="password2"/></br>
	<input type="submit" name="button" value="Зарегистрироваться"/>
</form>
