<?php

	$link = mysqli_connect("localhost", "Max", "516201", "Signup");
	$link->set_charset("utf8");

	if(isset($_POST['button1'])){
	$post = isset($_POST['post']) ? $_POST['post']: "";


	if($_POST['post'] == ''){
		echo "Комментарий не можем быть пустым!";
	}

	}

	if(!empty($_POST['post'])) {
		echo "Комментарий успешно отправлен! Спасибо!";

	mysqli_query ($link, 'INSERT INTO Post (post) VALUES ("'.$post.'")');
	} else "Неудача :(";
?>
