<?php

	require 'db.php';
	require 'signup_view.php';
