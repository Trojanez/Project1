<?php

	require 'post.php';
	require 'post_view.php';
