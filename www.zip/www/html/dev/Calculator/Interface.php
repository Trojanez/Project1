<?php

Class Calculator {

  	public function Calculate($operator) {
  		switch ($operator) {
  			case "+": $operation = new Sum($a, $b);
  			break;
  			case "-": $operation = new Min($a, $b);
  			break;
  			case "*": $operation = new Mul($a, $b);
  			break;
  			case "/": $operation = new Div($a, $b);
  			break;

  			echo $operation -> Calculate();
  		}
  	}
}