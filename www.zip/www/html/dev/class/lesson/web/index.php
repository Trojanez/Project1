<?php

class Room
{
    private $color = 'red';
    public $size = 'Big';

    public function changeColor($color)
    {
        $this->color = $color;
    }

    public function getColor()
    {
        return $this->color;
    }

    public function changeSize($size)
    {
    	$this->size = $size;
    }

    public function getSize()
    {
    	echo $this->size;
    }
}

$object = new Room;
$object-> changeSize('Little');
$object-> getSize();