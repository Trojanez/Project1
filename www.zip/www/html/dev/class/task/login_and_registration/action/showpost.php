<?php

require_once 'action/abstract.php';

class ActionAddpost extends ActionAbstract {

    public $viewTemplate = 'view/addpost.phtml';

    public function run() {
            $this->title = 'addpost';
			/* создаем подготавливаемый запрос */
			$dbLink = DbConnect::getInstance()->getLink();
			if($stmt = mysqli_prepare($dbLink, "SELECT * FROM post WHERE (date == now(), posts = ?)")) {
				/* связываем параметры с метками */
                mysqli_stmt_bind_param($stmt, "s", $addpost);

                /* запускаем запрос */
                mysqli_stmt_execute($stmt);

                $result = mysqli_stmt_get_result($stmt);
                /* получаем значения */
                $row = mysqli_fetch_all($result, MYSQLI_ASSOC);

                /* закрываем запрос */
                mysqli_stmt_close($stmt);
			}
			$this->showpost = $showpost;
    }
}