<?php

return array(
    '' => array(
        'filename' => 'action/login.php',
        'class' => 'ActionLogin',
    ),
    'login' => array(
        'filename' => 'action/login.php',
        'class' => 'ActionLogin',
    ),
    'registration' => array(
        'filename' => 'action/registration.php',
        'class' => 'ActionRegistration',
    ),
    'addpost' => array(
        'filename' => 'action/addpost.php',
        'class' => 'ActionAddpost',
    ),
    'showpost' => array(
        'filename' => 'action/showpost.php',
        'class' => 'ActionShowpost',
    ),
);