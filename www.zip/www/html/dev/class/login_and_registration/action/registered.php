<?php

class Valid {

	public $user_id;

	public function isAllowed(){

		$dbLink = DbConnect::getInstance()->getLink();

		mysqli_query($dblink, "SELECT * FROM user")
	}
}


$image = $_FILES['image'];

        $name = $image['name'];
        $type = $image['type'];
        $size = $image['size'];
        $blacklist = array(".php", ".phtml");
        foreach ($blacklist as $item) {
            if(preg_match("/$item\$/i", $name)) return false;
        }
        if (($type != "image/gif") && ($type != "image/png") && ($type != "image/jpg") && ($type != "image/jpeg")) return false;
        if ($size > 5 * 1024 * 1024) return false;
        return true;

        $type = $image['type'];
        $uploaddir = "/images";
        $name = md5(microtime()) . "." . substr($type, strlen("image/"));
        $uploadfile = $uploaddir . $name;
        if (move_uploaded_file($image["tmp_name"], $uploadfile)) {

        } else return false;