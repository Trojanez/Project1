<?php

require_once 'action/abstract.php';

class ActionAddpost extends ActionAbstract {

    public $viewTemplate = 'view/addpost.phtml';

    public function run() {
        if ($_SERVER['REQUEST_METHOD'] == 'POST'){
        $title = (string)isset($_POST['title']) ? trim($_POST['title']) : " ";
        $text = (string)isset($_POST['text']) ? trim($_POST['text']) : " ";


        if(!empty($_FILES['image']['tmp_name'])) {
            $fileInfo = pathinfo($_FILES['image']['name']);
            $filename = 'images/'.uniqid().'.' . $fileInfo['extension'];

            if(!move_uploaded_file($_FILES['image']['tmp_name'], $filename)) {
                exit("Не удалось загрузить изображение");
            }
        } else {
           exit("Необходимо загрузить изображение");
        }

            /* создаем подготавливаемый запрос */
            $dbLink = DbConnect::getInstance()->getLink();
            $stmt = mysqli_prepare($dbLink, "INSERT INTO post(user_id, title, teaser, text, image) VALUES(?, ?, ?, ?, ?)");

            if($stmt){

                ///@todo put right values here!!!
                $teaser = substr($text, 0, 2);
                $user_id = isset($_SESSION['user']['id']) ? $_SESSION['user']['id'] : "0";
                /* связываем параметры с метками */
                mysqli_stmt_bind_param($stmt, "issss", $user_id, $title, $teaser, $text, $filename);

                /* запускаем запрос */
                $success = mysqli_stmt_execute($stmt);
                if ($success) {
                        $this->messages['success'][] = 'Congrads, you are in!';
                    } else {
                        $this->messages['errors'][] = 'smth went wrong with database';
                        //$this->messages['errors'][] = mysqli_error($dbLink) ;//newer show database errors responce to user
                    }

                /* закрываем запрос */
                mysqli_stmt_close($stmt);
            }
                
        }
    }
}