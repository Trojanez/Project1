<?php

interface IAction {
    public function run();
    public function getHtml();
}