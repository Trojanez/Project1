<?php

require_once 'action/abstract.php';

class ActionShowpost extends ActionAbstract {

	public $title = 'posts';

    public $viewTemplate = 'view/showposts.phtml';

    public function run() {

        $dbLink = DbConnect::getInstance()->getLink();

		$query = "SELECT title, teaser, text, image FROM post ORDER BY id DESC";

        $result = mysqli_query($dbLink, $query);
        if (!$result) {
            exit(mysqli_error());
        }

        $row = array();
        for ($i = 0; $i < mysqli_num_rows($result); $i++) {
        $row = mysqli_fetch_array($result, MYSQLI_ASSOC);

        printf("<div style='margin:10px; border-bottom:2px solid #000'>
                <p style='font-size: 18px'>%s</p>
                <p>%s</p>
                <p>%s</p>
                <p><img style='margin-right:5px' width='150px' src='images/' >%s</p>
                </div>
            ",$row['title'], $row['teaser'], $row['text'], $row['image']);
}
}}