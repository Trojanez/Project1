<?php

	$link = mysqli_connect("localhost", "Max", "516201", "Signup");

