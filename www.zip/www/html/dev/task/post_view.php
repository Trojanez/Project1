<p>Введите Ваш комментарий:</p>
<form action="index.php"  method="post">
        <textarea name="post" placeholder="Ваш комментарий" style="width:300px; height:150px; border: 3px solid red;"></textarea></br>
        <input type="submit" name="button1" value="Добавить комментарий"/>
</form>