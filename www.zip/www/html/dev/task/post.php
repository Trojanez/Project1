<?php 

	

	class Post {
		public $post = "";

		public function GetPost() {
			if (isset($_POST['button1'])) {
				$this->post = $_POST['post'];
			}
		}
	}