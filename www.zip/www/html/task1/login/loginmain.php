<?php

	require 'database.php';
	require 'login1.php';
	require 'loginform.php';
