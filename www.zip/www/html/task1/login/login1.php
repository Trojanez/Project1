	$email = isset($_POST['email']) ? ($_POST['email']) : " ";
	$pass = isset($_POST['pass']) ? ($_POST['pass']) : " ";

	$query = 'SELECT * FROM Login WHERE email="'.$email.'"';
	$result = mysqli_query($query);

