<form method="post">

	<input type="email" name="email" placeholder="Электронный адрес"/>
	<input type="password" name="pass" placeholder="Пароль"/>
	<input type="submit" placeholder="Submit"/>
</form>
