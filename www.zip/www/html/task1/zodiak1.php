Введите Вашу дату рождения, что определить Ваш знак зодиака!

	<form>
	<input type="text" name="date" placeholder="Дата рождения"/></br>
	<input type="submit" value="GO"/></br>
	</form>
