<?php

	$sign = $_GET['date'];

	$marray = date_parse($sign);
	$year = current($marray);
	$mmonth = next($marray);
	$mday = next($marray);
	print_r($year. "-".$mday."-".$mmonth);


	echo myzodiak($mmonth, $mday);


	function myzodiak($m, $d){

	if ($m == 1 and  $d > 22){
	$z = "Козерог";
	}
	elseif ($m == 2 and $d < 21){
	$z = "Водолей";
	}
	elseif ($m == 2 and $d > 21){
	$z = "Водолей";
	}
	elseif ($m == 3 and $d < 20){
	$z = "Рыбы";
	}
	elseif ($m == 3 and $d > 20){
	$z = "Рыбы";
	}
	elseif ($m == 4 and $d < 21){
	$z = "Овен";
	}
	elseif ($m == 4 and $d > 21){
        $z = "Овен";
        }
	elseif ($m == 5 and $d < 21){
        $z = "Телец";
        }
	elseif ($m == 5 and $d > 21){
        $z = "Телец";
        }
	elseif ($m == 6 and $d < 22){
        $z = "Близнецы";
        }
	elseif ($m == 6 and $d > 22){
        $z = "Близнецы";
        }
	elseif ($m == 7 and $d < 22){
        $z = "Рак";
        }
	elseif ($m == 7 and $d > 22){
        $z = "Рак";
        }
	elseif ($m == 8 and $d < 24){
        $z = "Лев";
        }
	elseif ($m == 8 and $d > 24){
        $z = "Лев";
        }
	elseif ($m == 9 and $d < 24){
        $z = "Дева";
	}
	elseif ($m == 9 and $d > 24){
        $z = "Дева";
        }
	elseif ($m == 10 and $d < 24){
        $z = "Весы";
        }
	elseif ($m == 10 and $d > 24){
        $z = "Весы";
        }
	elseif ($m == 11 and $d < 24){
        $z = "Скорпион";
        }
	elseif ($m == 11 and $d > 24){
        $z = "Скорпион";
        }
	elseif ($m == 12 and $d < 23){
        $z = "Стрелец";
        }
	if ($m == 12 and $d > 23){
        $z = "Стрелец";
        }
	if ($m == 1 and $d < 22){
        $z = "Козерог";
        }
	return $z;


}







	function getZodiacalSign($month, $day) {
    $signs = array("Козерог", "Водолей", "Рыбы", "Овен", "Телец", "Близнецы", "Рак", "Лев", "Девы", "Весы", "Скорпион", "Стрелец");
    $signsstart = array(1=>22, 2=>21, 3=>20, 4=>21, 5=>21, 6=>22, 7=>22, 8=>24, 9=>24, 10=>24, 11=>24, 12=>23);
    return $day < $signsstart[$month + 1] ? $signs[$month - 1] : $signs[$month + 1];
  }

