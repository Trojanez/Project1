<?php

	require 'zodiak1.php';
	require 'zodiak2.php';
