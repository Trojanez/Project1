<?php

abstract class Figure {
	protected $cornerscount;

	public function getPerimeter() {
		return $this->perimeter;
	} 

	public function getSquare() {

	}

	public function getCornersCount() {
		return $this->cornerscount;
	}
}