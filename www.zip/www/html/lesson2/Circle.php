<?php 

class Circle extends Curve {
	private $r;
	protected $perimeter;
	protected $square;
	public function __construct($r){
		$perimeter = 2*M_PI*$r;
		echo "Периметр круга равен $perimeter" . "\n";

		$square = ($r*$r) * M_PI;
		echo "Площадь круга равна $square" . "\n";
	}
}