<?php

class User {
	public $id; 
	public $login; 
	public $email;
	public $password; 
	public $date;
}