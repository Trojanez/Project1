<?php

Class Reg extends User {
	public $password_confirm;
	private $err = [];

	public function __construct($login, $email, $password, $err) {
		$this->login = $login;
		$this->email = $email;
		$this->password = $password;
		$this->password_confirm;
		$this->date = date();
	}

	public function salt($salt, ) {

	}
}