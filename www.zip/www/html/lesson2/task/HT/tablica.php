<table border="2">
<?php

for ($i = 1; $i < 20; $i++) {
	echo "<tr>";
	for ($j = 1; $j < 20; $j++) {
		echo "<td>";
		echo ($i * $j);
		echo "</td>";
	}
	echo "</tr>";
}
?>
</table>