<?php

echo "Введите Ваше предложение: " . "\n";
$word = fgets(STDIN);

$a = str_word_count($word);
$b = str_word_count($word, 1);
$c = str_word_count($word, 2);

echo $a . "\n";
print_r($b);
print_r($c);