<?php
$N=rand(3,7);
echo "N=$N<br>";
?>
Before
<table border="1">
<?php for($i=0; $i<$N; $i++) { ?>
<tr>
<?php for($j=0; $j<$N; $j++) { ?>
	<td>
	<?php 
	if($i>$j) echo "<span style='color: #ff0000; font-weight: bold'>"; 
	echo "A<sub>$i$j</sub>=", $a[$i][$j]=rand(-10,20); 
	if($i>$j) echo "</span>"; 
	?>
	</td>
<?php } ?>
</tr>
<?php } ?>
</table>
After
<?php 
for($i=0; $i<$N; $i++)
	for($j=0; $j<$N; $j++)
		if($i>$j && $a[$i][$j]<0)
				$a[$i][$j]=0;
?>
<table border="1">
<?php for($i=0; $i<$N; $i++) { ?>
<tr>
<?php for($j=0; $j<$N; $j++) { ?>
	<td>
	<?php 
	if($i>$j) echo "<span style='color: #ff0000; font-weight: bold'>"; 
	echo "A<sub>$i$j</sub>=", $a[$i][$j]; 
	if($i>$j) echo "</span>"; 
	?>
	</td>
<?php } ?>
</tr>
<?php } ?>
</table>