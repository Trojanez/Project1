<?php

$n = 1000;
$m = 9999;

for ($i = $n; $i <= $m; $i++) {
	$res = (string)$i;
	if ($res[0]+$res[1] == $res[2]+$res[3]) {
		echo $res . "\n";
	}
}