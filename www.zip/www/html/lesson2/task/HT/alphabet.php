<?php

echo "Введите Вашу букву: ";
$res = fgets(STDIN);

if ((ord($res) < 65) && (ord($res) > 90) || (ord($res) < 97) && (ord($res) > 122) || (ord($res) < 192) && (ord($res) > 255)) {
	echo "Введите букву английского алфавита!";
} else {
	$res = chr(ord($res) + 1);
} echo "Следующая буква: " . $res . "\n";