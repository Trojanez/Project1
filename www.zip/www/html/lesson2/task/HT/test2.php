<?php

$min = 1; 
$max = 100;

$app = mt_rand($min, $max);

echo "Загадай число от 1 до 100 и нажми на кнопку 's'" . "\n";

$user = trim(fgets(STDIN), "\n");

if ($user == "s") {
	for ($i = 0; ; $i++) {

	echo "Скажи мне, загаданное тобой число, " . $app . "?" . "\n";

	$user = trim(fgets(STDIN), "\n");

	if ($min == $max) {
		if ($user == ">" || $user == "<") {
			echo "Эээээ, неееет! Ах ты врунишка! Твое число " . $app . " =)" . "\n"; break;
			echo "Попробуй снова =)" . "\n";
		}
	}
	if (($app > 100) || ($app < 1)) {
		echo "Твое число не может быть больше 100 или меньше 1! Скажи правильно число!" . "\n";
	}

	if($user == ">") {
		$min = $app + 1;
		$app = rand($min, $max);
	}elseif($user == "<") {
		$max = $app - 1;
		$app = rand($min, $max);
	}elseif($user == "=") {
		echo "Твое число: " . $app . "\n";
		echo "Ура! Я угадал с " . $i . " попытки!" . "\n"; break;
	}
}
} elseif (!($user == "s")) {
	echo "Для начала игры, Вам необходимо нажать на клавишу 's'" . "\n";
} 