<?php

$res = mt_rand(0, 1000);

for($i = 1; $i <= $res; $i++) {
	if ($res % $i == 0) {
		echo $i . "\n";
	}
}