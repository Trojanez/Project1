<?php

for ($i = 0; $i <= 10; $i++) {
	$arr[$i] = mt_rand(0,1000);
} print_r($arr);

print_r(min($arr));