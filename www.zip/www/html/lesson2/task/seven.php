<?php

$n = 20; 
$m = 10;
$k = 100;

for ($i = 0; $i <= $n; $i++) {
	$array[$i] = rand($m, $k);
	sort($array);
	} print_r($array);