<?php

$n = 10;
$m = 200;
$k = 1200;

	for ($i = 0; $i <= $n; $i++) {
		$array[$i] = rand($m, $k);
	} print_r (array_sum($array));

?>

<?php

$n = 10;
$m = 200;
$k = 1200;

$sum = 0;

	for ($i = 0; $i <= $n; $i++) {
		$array[$i] = rand($m, $k);

		$sum = $sum + $array[$i];
		
	} echo $sum . "\n";