<?php

class Check {
	public $i;
	public $j;

	public function ($i, $j) {
		echo '<table border = "1"><tr>';
		for ($i = 0; $i < 8; $i++) {
				echo '<tr>';
			for ($j = 0; $j < 8; $j++) {
				if(($i + $j + 1) % 2 == 0) {
					echo '<td bgcolor="black">' . $i . '</td>';
				} else {
					echo '<td>' . $i . '</td>';				}
			}
			echo '</tr>';
		}
		echo '</tr></table><br/>';
	}
}

$new = new Check;
$obj = $this->function($i, $j);