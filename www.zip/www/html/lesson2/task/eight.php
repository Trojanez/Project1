<?php

$n = 20; 
$m = 10;
$k = 100;

for ($i = 0; $i <= $n; $i++) {
	$array[$i] = rand($m, $k);

	if ($i % 2 == 0) {
		print_r ($array);
	}

	}