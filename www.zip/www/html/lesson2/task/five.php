<?php

$n = 10;
$m = 200;

$k = 7;

for ($i = $n; $i <= $m; $i++) {
	if ($i % $k == 0) {
		echo $i . "\n";
	}
}