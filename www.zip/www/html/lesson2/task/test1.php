<?php

$n = 10;

$k = 10;
$z = 100;


for($i = 0; $i <= $n; $i++) {
	$arr[$i] = mt_rand($k, $z);
} print_r($arr);

$filename = 'file1.txt';

$data = serialize($arr);
file_put_contents($filename, $data);

$data = file_get_contents($filename);
$arr = unserialize($data);

	function odd($i) {
	return ($i % 2 != 0);
	}
	print_r(array_filter($arr, "odd"));

	$filename1 = 'file2.txt';

	$data1 = serialize($arr);
	file_put_contents($filename1, $data1);

	$data1 = file_get_contents($filename1);
	$arr = unserialize($data1);