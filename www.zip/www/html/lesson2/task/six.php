<?php

$n = 40; 
$m = 10;
$k = 20;

for ($i = 0; $i <= $n; $i++) {
	$array[$i] = rand($m, $k);
	$arr = array_unique($array);
} print_r ($arr);