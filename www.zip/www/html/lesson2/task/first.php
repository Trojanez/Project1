<?php

$n = 10;
$m = 200;
do {
	$res = $n*$n*$n;
	$n++;

echo $res . "\n";

} while ($n <= $m);