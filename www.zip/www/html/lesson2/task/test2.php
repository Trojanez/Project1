<?php

$n = 1000;

$sum = 0;

for ($i = 1; $i <= $n; $i *= 9) {
	echo $i . "\n";
	$sum = $sum + $i;
} echo "Сумма равно = " . $sum . "\n";