<?php

Class Calculator {
	public $operation;

	public function Calculate($digit1, $operation, $digit2) {
		switch($operation){
			case "+": $operation = new Sum;
			default Die ("something went wrong");
		}
	}
	echo $operation->Calculate();
}