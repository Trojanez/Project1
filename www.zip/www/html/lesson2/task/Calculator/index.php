<?php

require "Sum.php"
require "Calculate.php";
require "form.phtml";