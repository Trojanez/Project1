<?php

Class Sum {
	public $digit1;
	public $digit2;
	
	public function Summa {
		return $digit1 + $digit2;
	}
}