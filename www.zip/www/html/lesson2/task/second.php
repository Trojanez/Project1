<?php

$n = 10;
$m = 200;
$s = 0;

for ($i=$n; $i<=$m; $i++) {
	$s+=$i;
} echo $s . "\n";