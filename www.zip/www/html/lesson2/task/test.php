<?php

$n = 0;
$m = 100; 

	do{
		if ($n % 2 == 0) {

		$res = $n*$n*$n;
		echo $res . "\n";
	} $n++;

	} while ($n <= $m);