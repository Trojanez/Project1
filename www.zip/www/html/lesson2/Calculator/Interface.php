<?php

Class Calculator {

  	public function Calculate($a, $result, $b) {
  		switch ($operator) {
  			case "+": $result = new Sum($a, $b); break;
  			case "-": $result = new Min($a, $b); break;
  			case "*": $result = new Mul($a, $b); break;
  			case "/": $result = new Div($a, $b); break;
        default: die("smth went wrong!");

        echo $result -> Calculate();
  		}
  	}
}