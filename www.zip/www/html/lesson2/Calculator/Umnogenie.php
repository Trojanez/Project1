<?php

Class Mul {
	private $a;
	private $b;

	public function Calculate() {
		return $a * $b;
	}

	public function __construct($a, $b) {
    $this->a = $a;
    $this->b = $b;
  }
}