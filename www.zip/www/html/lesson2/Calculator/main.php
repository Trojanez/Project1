<?php

require_once 'post.php';
require_once 'Sum.php';
require_once 'Minus.php';
require_once 'Division.php';
require_once 'Umnogenie.php';
require_once 'Interface.php';
require_once 'form.phtml';