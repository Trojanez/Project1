<?php

	class Triangle extends Polygon {
		protected $cornerscount = 3;
		protected $perimeter;
		protected $square;
		private $h;
		private $a, $b, $c;

		public function __construct($a, $b, $c) {
			$perimeter = $a + $b + $c;
			if ($a > $c || $b > $c) {
				echo "Введите правильные значения!" . "\n";
			} else {
				echo $perimeter . "\n";
			}
		}
		public function __construct($a, $h) {
			$square = (1/2*$a) * $h;
			echo $square . "\n";
		}
	}