<?php

abstract class Polygon extends Figure {

}