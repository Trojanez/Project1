<?php

abstract class Curve extends Figure {
	protected $cornerscount = 0;
}