<?php

class Elipse extends Curve {
	private $a;
	private $b;
	protected $perimeter;
	protected $square;
	public function __construct($a, $b){
		$perimeter = 4 * ((M_PI*$a*$b + ($a - $b))/($a+$b));
		echo "Периметр элипса равен $perimeter" . "\n";

		$square = ($a*$b) * M_PI;
		echo "Площадь элипса равна $square" . "\n";
	}
}