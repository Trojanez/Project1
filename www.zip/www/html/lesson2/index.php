<?php

spl_autoload_register(function($className){
	require_once $className . ".php";
});


$perimeter = new Square(12);
$perimeter = new Circle(8);
$perimeter = new Elipse(8, 5);