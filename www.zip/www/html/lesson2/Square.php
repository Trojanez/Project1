<?php

class Square extends Polygon {
	protected $cornerscount = 4;
	protected $perimeter;
	protected $square;
	private $a; 
	public function __construct($a){
		$perimeter = 4 * $a;
		echo "Периметр квадрата равен $perimeter" . "\n";

		$square = $a*$a;
		echo "Площадь квадрата равна $square" . "\n";
	}
}