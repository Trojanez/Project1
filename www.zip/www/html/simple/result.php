<?php

	$num = $_GET['number'];

	if ($num == "" or $num == 0){
		echo "Введите число!";
	}

	$i = 2;
	do {

	$res = $num % $i;

	if ($res == 0){
	break;
	}

	$i++;

	} while ($i < "$num - 1");
	if ($res != 0 || $num == 2){
		echo "Число простое!";
	} else echo "Число составное!";
