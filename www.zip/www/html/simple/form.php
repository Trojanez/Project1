<form>

	<input type="text" name="number" placeholder="число"/></br>
	<input type="submit" value="GO!"/>

</form>
