<?php

	require 'result.php';
	require 'form.php';
