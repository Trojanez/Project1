<?php

	$num = rand(100000, 999999);
	$digit = (string)$num;

	if (($digit{0}+$digit{1}+$digit{2}) == ($digit{3}+$digit{4}+$digit{5})){
		echo "Вы выиграли! Ваше число: " . "$digit[0]" . "$digit[1]" . "$digit[2]" . "$digit[3]" . "$digit[4]" . "$digit[5]" . "\n";
	} else echo "Вы проиграли! Ваше число: " . "$digit[0]" . "$digit[1]" . "$digit[2]" . "$digit[3]" . "$digit[4]" . "$digit[5]" . "\n";

?>
