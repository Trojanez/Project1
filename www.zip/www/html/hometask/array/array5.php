<?php

	for($i=0; $i < 10; $i++){
		$array[$i] = rand(0,1000);
	}

	for($i=0; $i < count($array)-1; $i++){
		if ($array[$i] > $array[$i+1]){
			$tmp = $array[$i];
			$array[$i] = $array[$i+1];
			$array[$i+1] = $tmp;
		}
	}
			print_r($array);
?>
