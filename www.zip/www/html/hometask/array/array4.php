<?php

	$j=rand(0,1000);
	for($i=0; $i < 10; $i++){
		$arr[$i]=$j++;

	}
	print_r ($arr);
?>
