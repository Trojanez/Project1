<?php

	for ($i = 0; $i < 10; $i++){
        for ($j = 0; $j < 10; $j++){
                $arr[$i][$j] = rand(1,1000);
        }}

	print_r($arr);

	$j = 9;
	for ($i = 0; $i < 10; $i++){

	$arr[$i][$i] = $arr[$i][$i] + $arr[$i][$j];
		$j--;
	}

	print_r($arr);
?>
