<?php
	$i = 3;
	do {

	echo "$i\n";

	$i = $i+5;

	} while ($i < 54);


	$j = 3;
	for ($i=0; $i <= 15; $i++) {
		echo "$j" . "-";

		$j = $j+5;
	}
?>
