<?php
	for ($i = 0; $i < 10; $i++){
	for ($j = 0; $j < 10; $j++){
		$arr[$i][$j] = rand(1,1000);
	}}

	for ($i = 0; $i < 10; $i++){
        for ($j = 0; $j < 10; $j++){


	if ($arr[$i][$j] % 2 == 0){
		$arr[$i][$j] = 0;
	}
	}}
		print_r ($arr);

?>
