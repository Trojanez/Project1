<?php

	$num = isset($_GET['number']) ? $_GET['number']: "";

	if ($num == ""){
	echo "Введите число!";
	}elseif ($num % 10 != 5){
                echo "Данная программа работает только для чисел, оканчивающихся на 5";
        } else {

		$res1 = (int)($num / 10);
		$res = ((($res1 * ($res1 + 1)) * 100) + 25);
		echo $res;
	}
