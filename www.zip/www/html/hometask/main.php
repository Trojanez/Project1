<?php

	require 'vasya.php';
	require 'form.php';
?>
