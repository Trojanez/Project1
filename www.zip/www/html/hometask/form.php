<p><b>Введите число оканчивающееся на 5 для возведения его в квадрат:</b></p>

<form>
	<input type="text" name="number" placeholder="Введите число"/></br>
	<input type="submit" value"Решить"/>
</form>
