<?php 

	require 'task1.php';
	require 'task2.php';
